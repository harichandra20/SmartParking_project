const express =require('express');
const mongoose = require('mongoose');
const app = express();
app.use(express.json());

const cors = require('cors')
app.use(cors()) 

/* app.get("/test",(req,res)=>{
    res.send("data is retuen");
}); */

const roleRoutes = require('./src/routes/roleRoutes');
app.use(roleRoutes);

const userRoutes=require('./src/routes/UserRoutes');
app.use(userRoutes);

mongoose.connect("mongodb://127.0.0.1:27017/25_node_imternship").then(()=>{
    console.log("database connected....")
})

const PORT = 3000;

app.listen(PORT,()=>{
    console.log("server is running port no " ,PORT);
})





/* console.log("hello");

var user = require('./user');
console.log(user.age);
console.log(user.name);
 */