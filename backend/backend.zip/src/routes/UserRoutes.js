const routes = require('express').Router();
const userController = require('../controller/UserController');

routes.post('/signup', userController.signup);
routes.post('/login',userController.login)
routes.delete('/deleteuser/:id',userController.deleteUser)
routes.get('/getuser/:id',userController.getoneUser)
routes.get('/getusers',userController.getAllUser)
module.exports = routes;
