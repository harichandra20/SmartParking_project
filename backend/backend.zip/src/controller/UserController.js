const userModel = require('../models/UserModel');
const bcrypt = require('bcrypt')


const login = async(req,res)=>{

   
  try {
    const { email, password } = req.body;

    // Check if email or password is missing
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Email and password are required.",
      });
    }

    // Find user by email
    const findUserFromEmail = await userModel.findOne({ email });

    if (!findUserFromEmail) {
      return res.status(404).json({
        success: false,
        message: "Email not found. Please sign up.",
      });
    }

    // Check if password matches
    const isMatch = bcrypt.compareSync(password, findUserFromEmail.password);

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: "Invalid credentials. Please try again.",
      });
    }

    // Successful login
    res.status(200).json({
      success: true,
      message: "Login successful!",
      data: findUserFromEmail,
    });

  } catch (error) {
    console.error("An error occurred:", error.message);
    res.status(500).json({
      success: false,
      message: "Internal server error. Please try again later.",
    });
  }

  
}


const signup = async (req, res) => {
  try {
    console.log(req.body);

    const salt = bcrypt.genSaltSync(10)
     const hashedPassword = bcrypt.hashSync(req.body.password, salt)
     req.body.password=hashedPassword

     console.log(req.body);

    const userAdded = await userModel.create(req.body);

    res.status(201).json({
      message: "User added successfully",
      data: userAdded
    });
  } catch (error) {
  
    console.error("Error adding user:", error.message);
    res.status(500).json({ message: "Internal Server Error", error: error.message });
  }
};



const deleteUser= async(req,res)=>{

    const deleteduser = await userModel.findByIdAndDelete(req.params.id)

    res.json({
        message : "deleted successfully",
        data: deleteduser

    })

};
const getAllUser = async(req,res)=>{

  const allUser = await userModel.find().populate("roleId","name")

  res.json({
      message : "user fetch success fulley",
      data:allUser
  })
}
const getoneUser = async(req,res)=>{

    const oneUser = await userModel.findById(req.params.id)

    res.json({
        message : "user fetch success fulley",
        data:oneUser
    })
}

module.exports = {
  signup,deleteUser,getoneUser,getAllUser,login
};
