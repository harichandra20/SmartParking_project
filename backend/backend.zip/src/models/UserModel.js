const mongoose = require('mongoose');

const Schema=mongoose.Schema;

const userSchema = new Schema({

         fullName :{
            type:String,
         },
         email :{
            type:String
         },
         PhoneNumber :{
            type:Number
         },
         role : {
            type:String
         },
         password : {
            type:String
         },
         roleId:{
            type:Schema.Types.ObjectId,
            ref:"roles"
         }


})

module.exports = mongoose.model("user",userSchema)