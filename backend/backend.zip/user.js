console.log("user file..")

var name ="harichnadra";
var age =20;

module.exports={
    name,
    age
};