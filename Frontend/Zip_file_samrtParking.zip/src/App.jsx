import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import { Route, Routes } from 'react-router-dom'
import { Login } from './components/common/Login'
import { SignUp } from './components/common/SignUp'
import { UserSidebar } from './components/layouts/UserSidebar'
import { AdminSidebar } from './components/layouts/AdminSidebar'
import { AddParking } from './components/admin/AddParking'

// import './App.css'

function App() {
  

  return (
    <body>
      <div >
        <Routes>
          <Route path='/login' element={<Login></Login>}></Route>
          <Route path='/signup' element={<SignUp></SignUp>}></Route>
          <Route path='/usersidebar' element={<UserSidebar></UserSidebar>}></Route>
        </Routes>
        <Routes>
          <Route path='/adminsidebar' element={<AdminSidebar></AdminSidebar>}></Route>
        </Routes>
        <Routes>
        <Route  path='/addparking' element={<AddParking></AddParking>}></Route></Routes>
      </div>
    </body>
  )
}

export default App
