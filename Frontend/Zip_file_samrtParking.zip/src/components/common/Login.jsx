import React, { useState } from 'react';
import { useForm } from 'react-hook-form';

export const Login = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [logindata, setlogindata] = useState({});

  const submithandler = (data) => {
    console.log('Login Data:', data);
    setlogindata(data);
  };

  const validators = {
    usernameValidator: {
      required: {
        value: true,
        message: "Username is required"
      }
    },
    passwordValidators: {
      required: {
        value: true,
        message: "Password is required"
      }
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-green-50">
      <form 
        onSubmit={handleSubmit(submithandler)} 
        className="bg-white p-8 rounded-lg shadow-md w-full max-w-md"
      >
        <h2 className="text-2xl font-bold mb-6 text-center">Login</h2>

        <div className="mb-4">
          <label htmlFor="username" className="block text-sm font-medium text-gray-700">Username</label>
          <input 
            type="text" 
            id="username"
            {...register('username', validators.usernameValidator)}
            className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <span className="text-red-500 text-sm">{errors.username?.message}</span>
        </div>

        <div className="mb-4">
          <label htmlFor="password" className="block text-sm font-medium text-gray-700">Password</label>
          <input 
            type="password" 
            id="password"
            {...register('password', validators.passwordValidators)}
            className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <span className="text-red-500 text-sm">{errors.password?.message}</span>
        </div>
       
       <button 
          type="submit"
          className="ml-35 bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition duration-300"
        >
          Submit
        </button>
       
        
      </form>
    </div>
  );
};
