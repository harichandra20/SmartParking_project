import React, { useState } from 'react';
import { useForm } from 'react-hook-form';

export const SignUp = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [signupdata, setsignupdata] = useState({});

  const submithandler = (data) => {
    console.log('Signup Data:', data);
    setsignupdata(data);
  };

  const validators = {
    usernameValidator: {
      required: {
        value: true,
        message: "Username is required"
      }
    },
    passwordValidators: {
      required: {
        value: true,
        message: "Password is required"
      }
    },
    confirmPasswordValidators: {
      required: {
        value: true,
        message: "Confirm password is required"
      }
    },
    emailValidators: {
      required: {
        value: true,
        message: "Email is required"
      }
    },
    phoneNumberValidators: {
      required: {
        value: true,
        message: "Phone number is required"
      }
    }
  };

  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
      <form onSubmit={handleSubmit(submithandler)} className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <h2 className="text-2xl font-bold mb-6 text-center">Sign Up</h2>

        <div className="mb-4">
          <label htmlFor="username" className="block text-sm font-medium text-gray-700">Username</label>
          <input type='text' id='username' {...register('username', validators.usernameValidator)} className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"/>
          <span className="text-red-500 text-sm">{errors.username?.message}</span>
        </div>

        <div className="mb-4">
          <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
          <input type='email' id='email' {...register('email', validators.emailValidators)} className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"/>
          <span className="text-red-500 text-sm">{errors.email?.message}</span>
        </div>

        <div className="mb-4">
          <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700">Phone Number</label>
          <input type='number' id='phoneNumber' {...register('phoneNumber', validators.phoneNumberValidators)} className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"/>
          <span className="text-red-500 text-sm">{errors.phoneNumber?.message}</span>
        </div>

        <div className="mb-4">
          <label htmlFor="password" className="block text-sm font-medium text-gray-700">Password</label>
          <input type='password' id='password' {...register('password', validators.passwordValidators)} className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"/>
          <span className="text-red-500 text-sm">{errors.password?.message}</span>
        </div>

        <div className="mb-4">
          <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">Confirm Password</label>
          <input type='password' id='confirmPassword' {...register('confirmPassword', validators.confirmPasswordValidators)} className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"/>
          <span className="text-red-500 text-sm">{errors.confirmPassword?.message}</span>
        </div>

        <button type='submit' className="w-full bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition duration-300">Submit</button>
      </form>
    </div>
  );
};
