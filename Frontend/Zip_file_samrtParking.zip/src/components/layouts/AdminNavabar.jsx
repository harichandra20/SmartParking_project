import React from 'react';

export const AdminNavabar = () => {
  return (
    <nav className="bg-blue-600 text-white shadow fixed w-full h-14 z-50" style={{ left: '250px' }}>
      <div className="flex justify-between items-center px-4 h-full">
        <ul className="flex items-center space-x-4">
          <li>
            <a className="text-white" href="#" role="button">
              <i className="bi bi-list" />
            </a>
          </li>
          <li><a href="#" className="text-white">Home</a></li>
          <li><a href="#" className="text-white">Contact</a></li>
        </ul>
        <ul className="flex items-center space-x-4">
          <li>
            <a className="text-white" href="#" role="button">
              <i className="bi bi-search" />
            </a>
          </li>
          <li>
            <a className="text-white" href="#">
              <i className="bi bi-bell-fill" />
              <span className="bg-yellow-400 text-black rounded-full text-xs px-2">15</span>
            </a>
          </li>
          <li>
            <a href="#" className="flex items-center text-white">
              <img src="../../dist/assets/img/user2-160x160.jpg" alt="User" className="rounded-full shadow w-8 h-8" />
              <span className="ml-2">Alexander Pierce</span>
            </a>
          </li>
        </ul>
      </div>
    </nav>
  );
};
