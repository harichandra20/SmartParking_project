import React from 'react';
import { AdminNavabar } from './AdminNavabar';
import { Outlet } from 'react-router-dom';

export const AdminSidebar = () => {
  return (
    <div className="flex">
      {/* Sidebar */}
      <aside className="bg-gray-200 shadow h-screen fixed w-64">
       
        <nav className="mt-4">
          <ul className="space-y-2">
            <li>
              <a href="#" className="flex items-center p-2 hover:bg-gray-300">
                <i className="bi bi-speedometer" />
                <span className="ml-2">Dashboard</span>
              </a>
            </li>
            <li>
              <a href="#" className="flex items-center p-2 hover:bg-gray-300">
                <i className="bi bi-palette" />
                <span className="ml-2">Theme Generate</span>
              </a>
            </li>
            <li>
              <a href="#" className="flex items-center p-2 hover:bg-gray-300">
                <i className="bi bi-box-seam-fill" />
                <span className="ml-2">Widgets</span>
              </a>
            </li>
          </ul>
        </nav>
      </aside>

      {/* Content Area */}
      <div className="ml-64 w-[calc(100%-250px)]">
        <AdminNavabar />
        <main className="p-4">
          <Outlet />
        </main>
      </div>
    </div>
  );
};
