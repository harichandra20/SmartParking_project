import React, { useState } from 'react';
import { useForm } from 'react-hook-form';

export const AddParking = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [parkingData, setParkingData] = useState({});

  const submitHandler = (data) => {
    console.log('Parking Data:', data);
    setParkingData(data);
  };

  const validators = {
    parkingNameValidator: {
      required: {
        value: true,
        message: "Parking name is required"
      }
    },
    totalSlotsValidator: {
      required: {
        value: true,
        message: "Total slots are required"
      },
      min: {
        value: 1,
        message: "At least 1 slot is required"
      }
    },
    pricePerHourValidator: {
      required: {
        value: true,
        message: "Price per hour is required"
      },
      min: {
        value: 0,
        message: "Price cannot be negative"
      }
    },
    parkingTypeValidator: {
      required: {
        value: true,
        message: "Parking type is required"
      }
    }
  };

  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
      <form onSubmit={handleSubmit(submitHandler)} className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <h2 className="text-2xl font-bold mb-6 text-center">Add Parking</h2>

        <div className="mb-4">
          <label htmlFor="parkingName" className="block text-sm font-medium text-gray-700">Parking Name</label>
          <input type='text' id='parkingName' {...register('parkingName', validators.parkingNameValidator)} className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"/>
          <span className="text-red-500 text-sm">{errors.parkingName?.message}</span>
        </div>

        <div className="mb-4">
          <label htmlFor="totalSlots" className="block text-sm font-medium text-gray-700">Total Slots</label>
          <input type='number' id='totalSlots' {...register('totalSlots', validators.totalSlotsValidator)} className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"/>
          <span className="text-red-500 text-sm">{errors.totalSlots?.message}</span>
        </div>

        <div className="mb-4">
          <label htmlFor="pricePerHour" className="block text-sm font-medium text-gray-700">Price per Hour</label>
          <input type='number' id='pricePerHour' {...register('pricePerHour', validators.pricePerHourValidator)} className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"/>
          <span className="text-red-500 text-sm">{errors.pricePerHour?.message}</span>
        </div>

        <div className="mb-4">
          <label htmlFor="parkingType" className="block text-sm font-medium text-gray-700">Parking Type</label>
          <select id='parkingType' {...register('parkingType', validators.parkingTypeValidator)} className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            <option value="">Select Parking Type</option>
            <option value="Car">Car</option>
            <option value="Bike">Bike</option>
            <option value="EV Charging">EV Charging</option>
          </select>
          <span className="text-red-500 text-sm">{errors.parkingType?.message}</span>
        </div>

        <button type='submit' className="w-full bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition duration-300">Add Parking</button>
      </form>
    </div>
  );
};
