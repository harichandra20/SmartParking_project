import axios from 'axios';
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';

export const SignUp = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();
 // const [signupdata, setsignupdata] = useState({});

  const submithandler = async(data) => {
    console.log("sign data",data)
    const res = await axios.post('/signup',data)
    console.log(res)
    console.log(res.data)

    if(res.status == 201){
      alert("user added success fuly")
    }
    else{
      alert("user will not added")
    }
    
    //setsignupdata(data); // Store submitted data
  };

  const validators = {
    usernameValidator: { required: { value: true, message: "Username is required" } },
    passwordValidators: { required: { value: true, message: "Password is required" } },
    confirmPasswordValidators: { required: { value: true, message: "Confirm password is required" } },
    emailValidators: { required: { value: true, message: "Email is required" } },
    phoneNumberValidators: { required: { value: true, message: "Phone number is required" } },
    roleValidator: { required: { value: true, message: "Role selection is required" } }
  };

  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
      <form onSubmit={handleSubmit(submithandler)} className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <h2 className="text-2xl font-bold mb-6 text-center">Sign Up</h2>

        {/* Username */}
        <div className="mb-4">
          <label htmlFor="fullname" className="block text-sm font-medium text-gray-700">full name</label>
          <input type='text' id='fullname' {...register('fullName', validators.usernameValidator)} className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"/>
          <span className="text-red-500 text-sm">{errors.fullname?.message}</span>
        </div>

        {/* Email */}
        <div className="mb-4">
          <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
          <input type='email' id='email' {...register('email', validators.emailValidators)} className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"/>
          <span className="text-red-500 text-sm">{errors.email?.message}</span>
        </div>

        {/* Phone Number */}
        <div className="mb-4">
          <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700">Phone Number</label>
          <input type='number' id='phoneNumber' {...register('PhoneNumber', validators.phoneNumberValidators)} className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"/>
          <span className="text-red-500 text-sm">{errors.phoneNumber?.message}</span>
        </div>

        {/* Password */}
        <div className="mb-4">
          <label htmlFor="password" className="block text-sm font-medium text-gray-700">Password</label>
          <input type='password' id='password' {...register('password', validators.passwordValidators)} className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"/>
          <span className="text-red-500 text-sm">{errors.password?.message}</span>
        </div>

     

        {/* Role Dropdown */}
        <div className="mb-6">
          <label htmlFor="role" className="block text-sm font-medium text-gray-700">Select Role</label>
          <select
            id="role"
            {...register('role', validators.roleValidator)}
            className="block w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Select a role</option>
            <option value="Admin">Admin</option>
            <option value="Security">Security</option>
            <option value="ParkingOwner">Parking Owner</option>
            <option value="User">User</option>
          </select>
          <span className="text-red-500 text-sm">{errors.role?.message}</span>
        </div>

        {/* Submit Button */}
        <button type='submit' className="w-full bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition duration-300">
          Submit
        </button>
      </form>
    </div>
  );
};
