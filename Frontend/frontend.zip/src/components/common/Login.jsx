import axios from 'axios';
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';

export const Login = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [logindata, setlogindata] = useState({});
  const [role, setRole] = useState('');

  const submithandler = async(data) => {

    try {
      const res = await axios.post('/login', data);
      console.log('Response:', res);

      // Handle response based on status codes
      if (res.status === 200) {
        alert('✅ Login successful!');
        setlogindata({ ...data, role });
      } else if (res.status === 400) {
        alert('⚠️ Bad request: ' + res.data.message);
      } else if (res.status === 401) {
        alert('❌ Unauthorized: ' + res.data.message);
      } else if (res.status === 404) {
        alert('🔍 Not found: ' + res.data.message);
      } else {
        alert('❗ Something went wrong. Please try again.');
      }
    } catch (error) {
      console.error('Login Error:', error);
      if (error.response) {
        // Server responded with a status other than 2xx
        alert('❗ Error: ' + error.response.data.message);
      } else {
        // Network error or server didn't respond
        alert('❗ Network error. Please check your connection.');
      }
    }
  };

  const validators = {
    usernameValidator: {
      required: {
        value: true,
        message: "Username is required"
      }
    },
    passwordValidators: {
      required: {
        value: true,
        message: "Password is required"
      }
    },
    roleValidator: {
      required: {
        value: true,
        message: "Role is required"
      }
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-green-50">
      <form 
        onSubmit={handleSubmit(submithandler)} 
        className="bg-white p-8 rounded-lg shadow-md w-full max-w-md"
      >
        <h2 className="text-2xl font-bold mb-6 text-center">Login</h2>

        <div className="mb-4">
          <label htmlFor="Email" className="block text-sm font-medium text-gray-700">Email</label>
          <input 
            type="text" 
            id="Email"
            {...register('email', validators.usernameValidator)}
            className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <span className="text-red-500 text-sm">{errors.email?.message}</span>
        </div>

        <div className="mb-4">
          <label htmlFor="password" className="block text-sm font-medium text-gray-700">Password</label>
          <input 
            type="password" 
            id="password"
            {...register('password', validators.passwordValidators)}
            className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <span className="text-red-500 text-sm">{errors.password?.message}</span>
        </div>

        <div className="mb-6">
          <label htmlFor="role" className="block text-sm font-medium text-gray-700">Select Role</label>
          <select
            id="role"
            {...register('role', validators.roleValidator)}
            value={role}
            onChange={(e) => setRole(e.target.value)}
            className="mt-1 block w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Select a role</option>
            <option value="Admin">Admin</option>
            <option value="Security">Security</option>
            <option value="ParkingOwner">Parking Owner</option>
            <option value="User">User</option>
          </select>
          <span className="text-red-500 text-sm">{errors.role?.message}</span>
        </div>

        {role && (
          <p className="text-md text-gray-700 mb-4">
            Selected Role: <span className="font-bold">{role}</span>
          </p>
        )}

        <button 
          type="submit"
          className="w-full bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition duration-300"
        >
          Submit
        </button>
      </form>
    </div>
  );
};
