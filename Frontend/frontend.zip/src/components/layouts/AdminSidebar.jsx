import React from 'react';
import { AdminNavabar } from './AdminNavabar';
import { Outlet } from 'react-router-dom';

export const AdminSidebar = () => {
  return (
    <div className="flex">
      {/* Sidebar */}
      <aside className="w-64 bg-gray-800 text-white fixed h-full shadow-lg">
        <div className="p-4 text-lg font-bold">Admin</div>
        <nav className="mt-4">
          <ul className="space-y-2">
            <li>
              <a href="#" className="flex items-center p-3 hover:bg-gray-700">
                <i className="bi bi-speedometer mr-2"></i> Dashboard
              </a>
            </li>   
            <li>
              <a href="#" className="flex items-center p-3 hover:bg-gray-700">
                <i className="bi bi-palette mr-2"></i>manage User
              </a>
            </li>
            <li>
              <a href="#" className="flex items-center p-3 hover:bg-gray-700">
                <i className="bi bi-box-seam-fill mr-2"></i> manage Parking
              </a>
            </li>
          </ul>
        </nav>
      </aside>

      {/* Content Area */}
      <div className="ml-64 w-[calc(100%-250px)]">
        <AdminNavabar />
        <main className="p-4">
          <Outlet />
        </main>
      </div>
    </div>
  );
};
