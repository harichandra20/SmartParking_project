import React from 'react';
import { Link } from 'react-router-dom';

export const UserNavbar = () => {
  return (
    <nav className="bg-white shadow-lg fixed top-0 left-64 right-0 z-50 p-4 flex justify-between items-center">
      <div className="flex space-x-4">
        <a href="#" className="text-gray-800">Home</a>
        <a href="#" className="text-gray-800">Contact</a>
      </div>
      <div className="flex space-x-4">
        <Link to="/login" className="bg-blue-500 text-white px-4 py-2 rounded">Login</Link>
        <Link to="/signup" className="bg-green-500 text-white px-4 py-2 rounded">Sign Up</Link>
       {/*  <Link to="/logout" className="bg-blue-500 text-white px-4 py-2 rounded">Log Out</Link> */}
      </div>
    </nav>
  );
};
