import React from 'react';
import { UserNavbar } from './UserNavbar';
import { Outlet } from 'react-router-dom';

export const UserSidebar = () => {
  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <aside className="w-64 bg-gray-800 text-white fixed h-full shadow-lg">
        <div className="p-4 text-lg font-bold">customer</div>
        <nav className="mt-4">
          <ul className="space-y-2">
            <li>
              <a href="#" className="flex items-center p-3 hover:bg-gray-700">
                <i className="bi bi-speedometer mr-2"></i> Dashboard
              </a>
            </li>
            <li>
              <a href="#" className="flex items-center p-3 hover:bg-gray-700">
                <i className="bi bi-palette mr-2"></i> Book Parking
              </a>
            </li>
            <li>
              <a href="#" className="flex items-center p-3 hover:bg-gray-700">
                <i className="bi bi-box-seam-fill mr-2"></i> Booking History
              </a>
            </li>
          </ul>
        </nav>
      </aside>

      {/* Content Area */}
      <div className="ml-64 flex-1">
        <UserNavbar />
        <main className="p-4">
          <Outlet />
        </main>
      </div>
    </div>
  );
};
